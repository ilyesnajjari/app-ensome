import React, { createContext, useState } from 'react';

export const EnqContext = createContext();

export const EnqProvider = ({ children }) => {
    const [enqueteurs, setEnqueteurs] = useState([]);

    return (
        <EnqContext.Provider value={{ enqueteurs, setEnqueteurs }}>
            {children}
        </EnqContext.Provider>
    );
};
