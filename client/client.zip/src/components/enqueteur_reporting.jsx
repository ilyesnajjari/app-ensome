import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { format, startOfWeek, addDays, startOfYear, addMonths } from 'date-fns';
import { useHistory } from 'react-router-dom';
import '../enqueteur_reporting.css';

const DataTable = () => {
    const [selectedDate, setSelectedDate] = useState(new Date());
    const [viewMode, setViewMode] = useState('daily');
    const [aggregationLevel, setAggregationLevel] = useState('individual');
    const [data, setData] = useState(() => JSON.parse(localStorage.getItem('data')) || {});
    const [users, setUsers] = useState([]);
    const [selectedUser, setSelectedUser] = useState('');
    const [errorMessage, setErrorMessage] = useState('');
    const history = useHistory();

    useEffect(() => {
        const fetchUsers = async () => {
            try {
                const response = await axios.get('http://localhost:5000/api/enq/enqueteur');
                setUsers(response.data);
            } catch (error) {
                console.error('Error fetching users', error);
                setErrorMessage('Error fetching users');
            }
        };

        fetchUsers();
    }, []);

    useEffect(() => {
        if (selectedUser) {
            const key = `${selectedUser}-${viewMode}-${aggregationLevel}`;
            if (!data[key]) {
                setData(prevData => ({
                    ...prevData,
                    [key]: {}
                }));
            }
        }
    }, [selectedUser, viewMode, aggregationLevel, data]);

    useEffect(() => {
        localStorage.setItem('data', JSON.stringify(data));
    }, [data]);

    const handleDateChange = (event) => {
        const newDate = new Date(event.target.value);
        setSelectedDate(newDate);
    };

    const getDaysOfWeek = (date) => {
        return Array.from({ length: 7 }, (_, i) => format(addDays(startOfWeek(date, { weekStartsOn: 1 }), i), 'EEEE, dd MMM'));
    };

    const getMonthsOfYear = (date) => {
        const startYear = startOfYear(date);
        return Array.from({ length: 12 }, (_, i) => format(addMonths(startYear, i), 'MMMM yyyy'));
    };

    const getHoursOfDay = () => {
        return Array.from({ length: 12 }, (_, i) => `${8 + i}h-${9 + i}h`);
    };

    let dates;
    if (viewMode === 'daily') {
        dates = getHoursOfDay();
    } else if (viewMode === 'weekly') {
        dates = getDaysOfWeek(selectedDate);
    } else {
        dates = getMonthsOfYear(selectedDate);
    }

    const handleReturnToDashboard = () => {
        history.push('/dashboard');
    };

    const calculateColumnTotal = (column) => {
        const key = `${selectedUser}-${viewMode}-${aggregationLevel}`;
        return dates.reduce((sum, date) => {
            const value = parseFloat(data[key]?.[date]?.[column] || 0);
            return sum + (isNaN(value) ? 0 : value);
        }, 0);
    };

    const calculateColumnAverage = (column) => {
        const key = `${selectedUser}-${viewMode}-${aggregationLevel}`;
        const total = calculateColumnTotal(column);
        const count = dates.length;
        return (total / count).toFixed(2);
    };

    const renderTableBody = () => {
        const key = `${selectedUser}-${viewMode}-${aggregationLevel}`;
            return dates.map((date, index) => (
                <tr key={index}>
                    <td>{date}</td>
                    <td>{data[key]?.[date]?.waitingTime || ''}</td>
                    <td>{data[key]?.[date]?.successfulCallTime || ''}</td>
                    <td>{data[key]?.[date]?.failedCallTime || ''}</td>
                    <td>{data[key]?.[date]?.breakTime || ''}</td>
                    <td>{data[key]?.[date]?.successfulCalls || ''}</td>
                    <td>{data[key]?.[date]?.failedCalls || ''}</td>
                    <td>{data[key]?.[date]?.breaks || ''}</td>
                    <td>{data[key]?.[date]?.totalPresenceTime || ''}</td>
                    <td>{data[key]?.[date]?.presenceWithoutBreaks || ''}</td>
                </tr>
            ));
        };

    const handleAggregationChange = (event) => {
        setAggregationLevel(event.target.value);
    };

    const handleUserChange = (event) => {
        const newUser = event.target.value;
        setSelectedUser(newUser);

        setData(prevData => {
            const updatedData = { ...prevData };
            const newKey = `${newUser}-${viewMode}-${aggregationLevel}`;
            updatedData[newKey] = updatedData[newKey] || {};
            return updatedData;
        });

        setSelectedDate(new Date()); // Réinitialiser la date sélectionnée pour forcer le composant à se réinitialiser
    };

    return (
        <div className="dataTableContainer">
            <input type="date" className="date-input" value={format(selectedDate, 'yyyy-MM-dd')} onChange={handleDateChange} />
            <button className="view-button" onClick={() => setViewMode('daily')}>Daily View</button>
            <button className="view-button" onClick={() => setViewMode('weekly')}>Weekly View</button>
            <button className="view-button" onClick={() => setViewMode('monthly')}>Monthly View</button>
            <button className="return-button" onClick={handleReturnToDashboard}>Return to Dashboard</button>
            <select className="aggregation-select" value={aggregationLevel} onChange={handleAggregationChange}>
                <option value="individual">Individual</option>
                <option value="team">Team</option>
                <option value="survey">Survey</option>
            </select>
            {aggregationLevel === 'individual' && (
                <select className="user-select" value={selectedUser} onChange={handleUserChange}>
                    <option value="">Select User</option>
                    {users.map(user => (
                        <option key={user.id} value={user.id}>{user.name}</option>
                    ))}
                </select>
            )}
            {selectedUser && (
                <table className="dataTable">
                    <thead>
                    <tr>
                        <th>Période</th>
                        <th>Temps en attente</th>
                        <th>Temps en appels aboutis</th>
                        <th>Temps en échecs</th>
                        <th>Temps en pause</th>
                        <th>Nb d'appels aboutis</th>
                        <th>Nb d'appels en échecs</th>
                        <th>Nb de pauses</th>
                        <th>Temps de présence total</th>
                        <th>Temps de présence hors pause</th>
                    </tr>
                    </thead>
                    <tbody>
                    {renderTableBody()}
                    </tbody>
                    <tfoot>
                    <tr>
                        <td>Total</td>
                        <td>{calculateColumnTotal('waitingTime')}</td>
                        <td>{calculateColumnTotal('successfulCallTime')}</td>
                        <td>{calculateColumnTotal('failedCallTime')}</td>
                        <td>{calculateColumnTotal('breakTime')}</td>
                        <td>{calculateColumnTotal('successfulCalls')}</td>
                        <td>{calculateColumnTotal('failedCalls')}</td>
                        <td>{calculateColumnTotal('breaks')}</td>
                        <td>{calculateColumnTotal('totalPresenceTime')}</td>
                        <td>{calculateColumnTotal('presenceWithoutBreaks')}</td>
                    </tr>
                    <tr>
                        <td>Moyenne</td>
                        <td>{calculateColumnAverage('waitingTime')}</td>
                        <td>{calculateColumnAverage('successfulCallTime')}</td>
                        <td>{calculateColumnAverage('failedCallTime')}</td>
                        <td>{calculateColumnAverage('breakTime')}</td>
                        <td>{calculateColumnAverage('successfulCalls')}</td>
                        <td>{calculateColumnAverage('failedCalls')}</td>
                        <td>{calculateColumnAverage('breaks')}</td>
                        <td>{calculateColumnAverage('totalPresenceTime')}</td>
                        <td>{calculateColumnAverage('presenceWithoutBreaks')}</td>
                    </tr>
                    </tfoot>
                </table>
            )}
            {errorMessage && <div className="error-message">{errorMessage}</div>}
        </div>
    );
};

export default DataTable;