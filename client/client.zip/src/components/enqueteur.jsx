import React, { useContext, useEffect, useState } from 'react';
import { useHistory } from 'react-router-dom';
import { UserContext } from '../context/UserContext';
import '../Enqueteur.css';

const Enqueteur = () => {
  const history = useHistory();
  const { user, setUser } = useContext(UserContext);
  const [isOnPause, setIsOnPause] = useState(false);
  const [pauseRecords, setPauseRecords] = useState([]);
  const [isPauseTooLong, setIsPauseTooLong] = useState(false);

  useEffect(() => {
    const savedPauseRecords = JSON.parse(localStorage.getItem(`pauseRecords_${user.id}`));
    if (savedPauseRecords) {
      setPauseRecords(savedPauseRecords);
    }
  }, [user]);

  useEffect(() => {
    if (isOnPause) {
      const timeout = setTimeout(() => {
        setIsPauseTooLong(true);
      }, 10000);
      return () => clearTimeout(timeout);
    }
  }, [isOnPause]);

  const handleLogout = () => {
    localStorage.removeItem('user');
    setUser(null);
    history.push('/');
  };

  const togglePause = () => {
    if (!isOnPause) {
      const pauseStart = Date.now();
      setIsOnPause(true);
      setPauseRecords([...pauseRecords, { start: pauseStart, end: null }]);
    } else {
      const pauseEnd = Date.now();
      setIsOnPause(false);
      const updatedRecords = [...pauseRecords];
      updatedRecords[updatedRecords.length - 1].end = pauseEnd;
      setPauseRecords(updatedRecords);
      localStorage.setItem(`pauseRecords_${user.id}`, JSON.stringify(updatedRecords));
      setIsPauseTooLong(false);
    }
  };

  const deletePauseRecord = (index) => {
    const updatedRecords = [...pauseRecords];
    updatedRecords.splice(index, 1);
    setPauseRecords(updatedRecords);
    localStorage.setItem(`pauseRecords_${user.id}`, JSON.stringify(updatedRecords));
  };

  const formatTime = (time) => {
    return new Date(time).toLocaleTimeString();
  };

  const handleDismissPauseAlert = () => {
    setIsPauseTooLong(false);
  };

  return (
      <div style={{ backgroundColor: isPauseTooLong ? 'red' : 'white', color: isPauseTooLong ? 'black' : 'inherit', minHeight: '100vh', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
        {isPauseTooLong ? (
            <div style={{ textAlign: 'center', padding: '50px' }}>
              <h1>PAUSE TROP LONGUE</h1>
              <button onClick={handleDismissPauseAlert} style={{ marginTop: '20px', padding: '10px 20px', backgroundColor: 'white', color: 'red', border: 'none', borderRadius: '5px', cursor: 'pointer' }}>OK</button>
            </div>
        ) : (
            <div>
              {user && (
                  <div>
                    <h2>Bienvenue {user.name} sur votre dashboard d'enquêteur !</h2>
                    <p>Enquête en cours: {user.enquete}</p>
                    <button className={'logout-button'} onClick={handleLogout}>Logout</button>
                    <button onClick={togglePause}>{isOnPause ? 'Revenir de pause' : 'Partir en pause'}</button>
                    {pauseRecords.length > 0 && (
                        <div>
                          <h3>Historique des pauses</h3>
                          <table>
                            <thead>
                            <tr>
                              <th>Début de pause</th>
                              <th>Fin de pause</th>
                              <th>Durée</th>
                              <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            {pauseRecords.map((record, index) => (
                                <tr key={index}>
                                  <td>{formatTime(record.start)}</td>
                                  <td>{record.end ? formatTime(record.end) : 'En cours'}</td>
                                  <td>{record.end ? ((record.end - record.start) / 1000).toFixed(2) + ' secondes' : 'En cours'}</td>
                                  <td><button onClick={() => deletePauseRecord(index)}>Supprimer</button></td>
                                </tr>
                            ))}
                            </tbody>
                          </table>
                        </div>
                    )}
                  </div>
              )}

            </div>
      )}
    </div>
  );
};

export default Enqueteur;
