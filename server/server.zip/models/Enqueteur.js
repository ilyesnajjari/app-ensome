const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const enqueteurSchema = new mongoose.Schema({
    name: { type: String, required: true },
    enquete: { type: String, required: true },
    status: { type: String, required: true },
    time: { type: String, required: true }});

const Enqueteur = mongoose.model('Enqueteur', enqueteurSchema);

module.exports = Enqueteur;