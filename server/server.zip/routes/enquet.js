const express = require('express');
const Enqueteur = require('../models/Enqueteur');
const router = express.Router();

// Route pour récupérer tous les enquêteurs
router.get('/enqueteur', async (req, res) => {
    try {
        const enqueteurs = await Enqueteur.find({});
        res.json(enqueteurs);
    } catch (err) {
        console.error(err.message);
        res.status(500).json({ message: 'Server Error' });
    }
});

module.exports = router;
