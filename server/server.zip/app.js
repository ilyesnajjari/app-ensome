const express = require('express');
const bodyParser = require('body-parser');
const authRoutes = require('./routes/auth');
const enquetRoutes = require('./routes/enquet');

const app = express();

app.use(bodyParser.json());
app.use(express.json());

app.use('/api', authRoutes);
app.use('/api/enq', enquetRoutes);
module.exports = app;
